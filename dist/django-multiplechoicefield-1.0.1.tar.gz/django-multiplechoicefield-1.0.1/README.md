This Package installs a Django Modelfield which takes a standard Django choices list and turns it into a MultipleChoiceField.
